Python module API reference
===========================




Module ``rmsynthesis.rmsynthesismain``
--------------------------------------

.. automodule:: rmsynthesis.rmsynthesismain
   :members:


Module ``rmsynthesis.fits``
---------------------------
.. automodule:: rmsynthesis.fits
   :members:
