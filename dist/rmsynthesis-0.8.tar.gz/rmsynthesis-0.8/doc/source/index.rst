.. RM-Synthesis documentation master file, created by
   sphinx-quickstart on Mon Jan 30 10:43:10 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to RM-Synthesis's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   apidoc

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

